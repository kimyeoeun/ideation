package com.example.number1;


import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.MotionEvent;

import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;

import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;

import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Window;//수정
import java.util.ArrayList;
import java.util.HashMap;



public class MainActivity extends AppCompatActivity {
    private static MyPaintView myView;


    private ColorAdapter colorAdapter;

    private static HashMap<Integer, Bitmap> colorBitmapMap = new HashMap<>();
    private static HashMap<Integer, Canvas> colorCanvasMap = new HashMap<>();
    int selectedColor = -1;



    int Black, colorRed, colorPink, permaOrange,lightOrange, naplesYellow, green, oliveGreen,
            emraldGreen, pearlGreen, ceruleanBlue, pearlMarine, briliantPurple, violet, lightMagenta;

    private static int[] colors;


    int count = 0;

    private EditText Text;

    private float x,y; //tnwjd

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Text = findViewById(R.id.Text);


        SharedPreferences preferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();


        String savedText = preferences.getString("text_key", "");

        Button TextBoxButton = findViewById(R.id.showTextBoxButton);
        TextBoxButton.setOnClickListener((new View.OnClickListener() {
                    @SuppressLint("ClickableViewAccessibility")
                    @Override
                    public void onClick(View view) {
                        final Dialog TextDialog = new Dialog(view.getContext(), android.R.style.Theme_Translucent_NoTitleBar);//tnwjd

                        TextDialog.setContentView(R.layout.custom_dialog);
                        TextDialog.setTitle("TextBox");


                        //수정
                        TextDialog.getWindow().getDecorView().setOnTouchListener((view1, motionEvent) -> {
                            switch (motionEvent.getAction()) {
                                case MotionEvent.ACTION_DOWN:
                                    x = motionEvent.getX();
                                    y = motionEvent.getY();
                                    break;

                                case MotionEvent.ACTION_MOVE:
                                    float deltaX = motionEvent.getX() - x;
                                    float deltaY = motionEvent.getY() - y;

                                    Window window = TextDialog.getWindow();
                                    if (window != null) {
                                        WindowManager.LayoutParams params = window.getAttributes();
                                        params.x += deltaX;
                                        params.y += deltaY;
                                        window.setAttributes(params);
                                    }
                                    break;

                                default:
                                    break;
                            }
                            return true;
                        });





                        final EditText editText = (EditText) TextDialog.findViewById(R.id.Text);


                        Button done = (Button) TextDialog.findViewById(R.id.done);


                        TextDialog.setCanceledOnTouchOutside(true);//tnwjd

                        done.setOnClickListener(new View.OnClickListener(){


                            @Override
                            public void onClick(View view) {

                                try {
                                    EditText Text = findViewById(R.id.Text);
                                    String inputText = editText.getText().toString().trim();

                                    if (inputText.length() > 0) {

                                        SharedPreferences.Editor editor = preferences.edit();
                                        editor.putString("text_key", inputText);
                                        editor.apply();


                                        Toast.makeText(getApplicationContext(), "완료", Toast.LENGTH_LONG).show();


                                        editText.clearFocus();

                                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                                        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);

                                        done.setVisibility((View.GONE));
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }





                        });

                        TextDialog.show();

                    }
                })

        );

        Button clearButton = findViewById(R.id.btnClear);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myView.clearCanvas(); // 클리어 버튼을 누를 때 MyPaintView의 clearCanvas() 메서드 호출
            }
        });


        Button showPaletteButton = findViewById(R.id.showPaletteButton);
        GridView colorPalette = findViewById(R.id.colorPalette);


        showPaletteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showPaletteDialog();
            }
        });

        colorRed = getResources().getColor(R.color.colorRed);
        colorPink = getResources().getColor(R.color.colorPink);
        permaOrange = getResources().getColor(R.color.permaOrange);
        lightOrange = getResources().getColor(R.color.lightOrange);
        naplesYellow = getResources().getColor(R.color.naplesYellow);
        green = getResources().getColor(R.color.green);
        oliveGreen = getResources().getColor(R.color.oliveGreen);
        emraldGreen = getResources().getColor(R.color.emeraldGreen);
        pearlGreen = getResources().getColor(R.color.pearlGreen);
        ceruleanBlue = getResources().getColor(R.color.ceruleanBlue);
        pearlMarine = getResources().getColor(R.color.pearlMarine);
        briliantPurple = getResources().getColor(R.color.briliantPurple);
        violet = getResources().getColor(R.color.violet);
        lightMagenta = getResources().getColor(R.color.lightMagenta);
        Black = getResources().getColor(R.color.Black);

        colors = new int[] {
                colorRed, colorPink, permaOrange,lightOrange, naplesYellow, green, oliveGreen,
                emraldGreen, pearlGreen, ceruleanBlue, pearlMarine, briliantPurple, violet, lightMagenta

        };

        colorPalette = findViewById(R.id.colorPalette);
        colorAdapter = new ColorAdapter(this, colors);
        colorPalette.setAdapter(colorAdapter);

        colorPalette.setVisibility((View.GONE));

        GridView finalColorPalette = colorPalette;
        showPaletteButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if (finalColorPalette.getVisibility() == View.VISIBLE){
                    finalColorPalette.setVisibility((View.GONE));
                } else {
                    finalColorPalette.setVisibility(View.VISIBLE);
                }
            }
        });

        colorPalette.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                int selectedColor = colors[position];
                myView.mPaint.setColor(selectedColor);


            }
        });









        setTitle("Ideation");
        myView = new MyPaintView(this);

        ((LinearLayout) findViewById(R.id.paintLayout)).addView(myView);


        Button btnTh = findViewById(R.id.btnTh);
        btnTh.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(count%2==1){
                    btnTh.setText("Thin");
                    myView.mPaint.setStrokeWidth(10);
                    count++;
                } else {
                    btnTh.setText("Thick");
                    myView.mPaint.setStrokeWidth(20);
                    count++;
                }
            }
        }));



        ((Button)findViewById(R.id.btnClear)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myView.clearCanvas();
            }



        });






    }



    private void showPaletteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.palette_dialog_layout, null);
        builder.setView(dialogView);

        GridView colorGridView = dialogView.findViewById(R.id.colorGridView);
        colorAdapter = new ColorAdapter(this, colors);
        colorGridView.setAdapter(colorAdapter);

        colorGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedColor = colors[position];
                myView.mPaint.setColor(selectedColor);
                myView.restoreBackupBitmap();
            }
        });

        // 다이얼로그 생성 및 표시
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }






    private static class MyPaintView extends View {
        private Bitmap mBitmap;
        private Canvas mCanvas;
        private Path mPath;
        private Paint mPaint;

        private Bitmap mBackupBitmap;
        private Canvas mBackupCanvas;

        private Path mCurrentPath; // 현재 그리는 그림의 Path
        private Paint mCurrentPaint; // 현재 그리는 그림의 Paint
        private ArrayList<Path> mPaths = new ArrayList<>(); // 저장된 그림들의 Path 리스트
        private ArrayList<Paint> mPaints = new ArrayList<>(); // 저장된 그림들의 Paint 리스트





        public MyPaintView(Context context) {
            super(context);
            mPath = new Path();
            mPaint = new Paint();
            mPaint.setColor(Color.BLACK);
            mPaint.setAntiAlias(true);
            mPaint.setStrokeWidth(10);
            mPaint.setStyle(Paint.Style.STROKE);





        }


        public void restoreBackupBitmap() {
            mBitmap = Bitmap.createBitmap(mBackupBitmap);
            mCanvas = new Canvas(mBitmap);

        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);


            for (int color : colors) {
                Bitmap colorBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Canvas colorCanvas = new Canvas(colorBitmap);
                colorBitmapMap.put(color, colorBitmap);
                colorCanvasMap.put(color, colorCanvas);
            }


            mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            mCanvas = new Canvas(mBitmap);
            mBackupBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            mBackupCanvas = new Canvas(mBackupBitmap);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            canvas.drawBitmap(mBitmap, 0, 0, null); //지금까지 그려진 내용

            for (int i = 0; i < mPaths.size(); i++) {
                canvas.drawPath(mPaths.get(i), mPaints.get(i));
            }

            // 현재 그리는 그림도 그려줍니다.
            if (mCurrentPath != null && mCurrentPaint != null) {
                canvas.drawPath(mCurrentPath, mCurrentPaint);
            }

            canvas.drawPath(mPath, mPaint); //현재 그리고 있는 내용



        }


        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int x = (int) event.getX();
            int y = (int) event.getY();

            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                mCurrentPath = new Path();
                mCurrentPath.moveTo(x, y);
                mCurrentPaint = new Paint(mPaint);
                mPaths.add(mCurrentPath); // 현재 그림의 Path 저장
                mPaints.add(mCurrentPaint); // 현재 그림의 Paint 저장
            } else if (event.getAction() == MotionEvent.ACTION_MOVE) {
                mCurrentPath.lineTo(x, y);
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                mCurrentPath.lineTo(x, y);
                mCanvas.drawPath(mCurrentPath, mCurrentPaint); // mBitmap 에 기록
                mCurrentPath = null; // 현재 그림의 Path 초기화
                mCurrentPaint = null; // 현재 그림의 Paint 초기화
            }


            this.invalidate();
            return true;
        }



        public void clearCanvas() {
            // 현재 그림들의 Path 리스트와 Paint 리스트 초기화
            mPaths.clear();
            mPaints.clear();

            // Bitmap 및 Canvas 초기화
            mBitmap.eraseColor(Color.TRANSPARENT);
            mBackupBitmap.eraseColor(Color.TRANSPARENT);

            // Canvas 지우기
            mCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
            mBackupCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);

            invalidate(); // 화면 갱신
        }





    }




    private class ColorAdapter extends BaseAdapter {

        private Context context;
        private int[] colors;

        ColorAdapter(Context context, int[] colors) {
            this.context = context;
            this.colors = colors;
        }

        @Override
        public int getCount() {
            return colors.length;
        }

        @Override
        public Object getItem(int position) {
            return colors[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View colorView = convertView;
            if (colorView == null) {
                colorView = LayoutInflater.from(context).inflate(R.layout.color_item, parent, false);
            }
            colorView.setBackgroundColor(colors[position]);
            return colorView;
        }
    }



}