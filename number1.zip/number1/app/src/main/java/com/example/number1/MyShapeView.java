package com.example.number1;



import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public class MyShapeView extends View {
    private Paint shapePaint = new Paint();
    private ShapeType currentShape = ShapeType.NONE; // 도형 유형

    private float startX, startY, endX, endY; // 시작점과 끝점

    public MyShapeView(Context context) {
        super(context);
        init();
        shapePaint.setColor(Color.BLUE);
        shapePaint.setStyle(Paint.Style.STROKE);
        shapePaint.setStrokeWidth(5);
    }

    private void init(){

        Canvas mCanvas = new Canvas();
        Path mPath = new Path();
    }


    // 도형 유형 설정
    public void setCurrentShape(ShapeType shapeType) {
        currentShape = shapeType;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // 도형 그리기
        if (currentShape == ShapeType.RECTANGLE) {
            canvas.drawRect(startX, startY, endX, endY, shapePaint);
        } else if (currentShape == ShapeType.CIRCLE) {
            float radius = Math.max(Math.abs(endX - startX), Math.abs(endY - startY)) / 2;
            canvas.drawCircle(startX, startY, radius, shapePaint);
        }
    }

    // 시작점 설정
    public void setStartPoint(float x, float y) {
        startX = x;
        startY = y;
    }

    // 끝점 설정
    public void setEndPoint(float x, float y) {
        endX = x;
        endY = y;
        invalidate();
    }

    public enum ShapeType {
        NONE, RECTANGLE, CIRCLE
    }
}

